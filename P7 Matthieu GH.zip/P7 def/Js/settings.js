// 4 -Controller
var jsonFile = 'Data/restaurants.json'; // Nom du fichier Json appellé
console.log (jsonFile) 

// 1- Map init
var userPosition = {lat: 48.8747648, lng: 2.348376}; // Position par default de la carte

var defaultZoom = 16; // Zoom de la carte

var liIndex = '';

var listeRestaurants = [];

// Liste des places id importées de google maps
let listPlaceIds = [];


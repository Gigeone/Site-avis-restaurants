var doubleSlider = document.getElementById('test-slider');

function handleLocationError(browserHasGeolocation, infoWindow, pos) {
    infoWindow.setPosition(pos);
    infoWindow.setContent(browserHasGeolocation ?
                              'Error: The Geolocation service failed.' :
                              'Error: Your browser doesn\'t support geolocation.');
    infoWindow.open(map);
}

  // Méthode de calcul de la moyenne des notes
function avgRating(ratings){
        // On initialise les variables
        let numerateur = 0;
        let moyenne = 0;
        // Si pas d'avis
        if (ratings.length === 0){
            // On retourne une string
            return "Pas d'avis déposé sur cet établissement";
        }
        // S'il y a au moins 1 avis
        else {
            // On boucle sur les ratings
            for (let rating of ratings){
                numerateur += rating.stars;
            }
            // On retourne la moyenne avec 1 chiffre après la virgule
            moyenne = Math.round((numerateur/ratings.length)*10)/10;
            return moyenne;
        }
}

// Creation du double Slider Control
function createRangeSlider(min, max, myStep, MinStart, MaxStart){

  noUiSlider.create(doubleSlider, {
   start: [min, max],
   connect: true,
   step: myStep,
   orientation: 'horizontal', // 'horizontal' or 'vertical'
   range: {
     'min': MinStart,
     'max': MaxStart
   },
   pips: {
        mode: 'steps',
        density: 3,
        format: wNumb({
            decimals: 1,
            
        })
    }
   
 });

doubleSlider.noUiSlider.on('set', function () { 
          for (let restaurant in listeRestaurants){
            checkRestaurants();
          };
})
}

// Check de la moyenne du restaurant et affichage ssi compris entre le bornes du slider
function checkAvgRateRestaurant(restaurantObj){
    // Recuperation des bornes
    let minRateing = Number(doubleSlider.noUiSlider.get()[0]);
    let maxRateing = Number(doubleSlider.noUiSlider.get()[1]);  
        if ((restaurantObj.avgRate < minRateing) || (restaurantObj.avgRate > maxRateing)){
            // Si non, on masque l'élément dans la sidebar et son marqueur
            restaurantObj.hideSideBar();
            restaurantObj.hideMarker();
        }
        else{
            restaurantObj.showSideBar(); 
            restaurantObj.showMarker();  
        }
    
};

// Check de position des restaurant et affichage ssi dans un rayon de 1 km et moyenne comprise entre les bornes du slider
function checkRestaurants(){
    // On vérifie que la liste n'est pas vide
    if ([listeRestaurants].length > 0){
        // On boucle sur tous les restaurants
        for (let restaurant in listeRestaurants){
            // Création d'un objet latlng à la position de l'utilisateur
            let userLatLng = new google.maps.LatLng(userPosition.lat, userPosition.lng);
            // Si le marqueur du restaurant est dans les 1000 m autour de la user position
            let distance =  google.maps.geometry.spherical.computeDistanceBetween(listeRestaurants[restaurant].marker.position, userLatLng);
            // Si en dehors du rayon de 1000m
            if (distance > 1000){
                // On masque l'élément dans la sidebar et son marqueur
                listeRestaurants[restaurant].hideSideBar();
                listeRestaurants[restaurant].hideMarker();
            }
            // Si dans le rayon de 1000m
            else{
                // On vérifie que sa moyenne est comprise dans les bornes du slider, si oui, on l'affiche
                checkAvgRateRestaurant(listeRestaurants[restaurant]);
            }
        }
    }
}

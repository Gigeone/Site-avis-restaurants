// Fonction Collapasible Materialize
$(document).ready(function(){
    $('.collapsible').collapsible();
    
  });

$(document).ready(function(){
    createRangeSlider(0, 5, 0.5, 0, 5);
    
  });

  $(document).ready(function(){
    $('#modal1').modal();
  });

  $(document).ready(function(){
    $('#modal2').modal();
  });

// Évènement à la validation de la modale pour ajout d'un nouvel avis
$(document).ready(function(){
    $('#validModalBtn').on("click", function(e){
        // On récupère l'id de restaurant
        let restaurantId = lastmodified.value;
        // On ajoute l'avis à l'objet
        listeRestaurants[restaurantId].addRating();
        // On update la sidebar du restaurant
        listeRestaurants[restaurantId].updateSideBar();
    });
  });




    


// Call Json à notre fichier test.json où sont stockés les données des restaurants
$(document).ready(function() {
        $.getJSON(jsonFile, function(data){ 
            $.each(data, function(index){
                    // Création d'une instance de Restaurant et affectation de l'id
                    let restaurantObj = new Restaurant(index, data[index]);
                    listeRestaurants.push(restaurantObj);
                    var nbMarker = (index+1).toString(); // On définit l'id
                    console.log(nbMarker)
                    // Ajout du restaurant à la sidebar
                    restaurantObj.addRestaurantToSidebar();
                    // Ajout du marqueur du restaurant sur la carte
                    restaurantObj.addMarker(index); // On ajoute le marker sur la map
                    // Stockage du restaurant dans la liste globale
                    listeRestaurants[restaurantObj.id] = restaurantObj;
                });
            });
});



 // Évènement au clic droit sur la carte : ajout de restaurant
map.addListener("rightclick", function(e){
    // On unbind le submit et on le relance pour éviter qu'il ajoute plusieurs restaurants après plusieurs clicks et un seul ajout.
    $('#modal2').modal('open'); // On ouvre le modal d'ajout de restaurant
    $('#formRestaurant').unbind('submit').submit();
    // On remet les valeurs du modal à 0
    
     // Calcul du dernier indice
                let index = listeRestaurants.length;
                console.log(index)
                // Création d'un nouveau restaurant
                let newRestaurant = new Restaurant(index);
                // Affectation de la localisation à partir de la zone du clic droit
                newRestaurant.location.lat = e.latLng.lat();
                newRestaurant.location.lng = e.latLng.lng();   
    
    let geocoder = new google.maps.Geocoder();
    // Geocodage pour récupérer l'adresse de l'endroit où l'on a cliqué et la mettre dans l'input du modal
    geocoder.geocode({'location': e.latLng }, function(results, status) {
        if (status === 'OK') {
            if (results[0]) {                        
                newRestaurant.address = $('#newRestaurantAddress').val(results[0].formatted_address);             
            } else {
            window.alert('No results found');
        }
        } else {
        window.alert('Geocoder failed due to: ' + status);
        }
    });

    $('#formRestaurant').on("click", function(e){
      $('#formRestaurant').off("click");
      $('#modal2').modal('close'); // On ferme le modal
      newRestaurant.restaurantName = $('#newRestaurantName').val();
      newRestaurant.address = $('#newRestaurantAddress').val();
      newRestaurant.addRestaurantToSidebar();
      // Ajout sur la carte
      newRestaurant.addMarker((index+1).toString(), index);
      // Ajout dans la liste des restaurants
      listeRestaurants.push(newRestaurant);
      listeRestaurants[newRestaurant.id] = newRestaurant;
    });
    

});

// Fonction pour ajouter les restaurants alentours

  map.addListener("dragend", function(e){
  // Mise à jour de la position de l'utilisateur
        userPosition.lat = map.getCenter().lat();
        userPosition.lng = map.getCenter().lng();
        // Lancement du service
        let service = new google.maps.places.PlacesService(map);
        // Options de la requête
        let request = {
            location: userPosition,
            radius: '500',
            type: ['restaurant']
          };

  service.nearbySearch(request, function(results, status){
            // Si la requête a réussi
            if (status == google.maps.places.PlacesServiceStatus.OK){
                // Calcul du dernier indice
                let index = listeRestaurants.length;
                // On initialise l'incrément d'indice (obligatoire pour conserver une numérotation correct lorsqu'on trouve des restaurants déjà importés)
                let inc = 0;
                // On boucle sur les résultats
                for (let i = 0; i < results.length; i++){
                    // On vérifie que le restaurant n'a pas déjà été importée
                    if (!listPlaceIds.includes(results[i].place_id)){
                        // Création d'un nouveau restaurant
                        let newRestaurant = new Restaurant(index + inc);
                        // On ajoute 1 à l'incrément
                        inc++;
                        // Affectation de la localisation
                        newRestaurant.location.lat = results[i].geometry.location.lat();
                        newRestaurant.location.lng = results[i].geometry.location.lng();
                        // Affectation du nom du restaurant
                        newRestaurant.restaurantName = results[i].name;       
                        // On affecte l'adresse au restaurant
                        newRestaurant.address = results[i].vicinity;
                        // Ajout de la placeid à la liste des restaurants importés
                        listPlaceIds.push(results[i].place_id);
                        // Ajout dans la sidebar - synchrone de la boucle for pour conserver un compte logique des li / restaurants
                        newRestaurant.addMarker((index+inc).toString(), index+inc);
                        listeRestaurants.push(newRestaurant);
                        // Ajout dans la liste des restaurants
                        listeRestaurants[newRestaurant.id] = newRestaurant;
                        // Récupération des détails sur la place
                        let reqDetails = {
                            // Place en cours de lecture dans la boucle
                            placeId: results[i].place_id,
                            // Il nous manque uniquement les reviews
                            
                        }
                         // Lancement de la requête
                        service.getDetails(reqDetails, function(place, status){
                            // L'obtention des reviews a réussi
                            if (status == google.maps.places.PlacesServiceStatus.OK){
                                // S'il existe des avis
                                if (place.reviews){
                                // On boucle sur les avis
                                    for (let review of place.reviews){
                                        // Création d'un objet litteral
                                        let avis = {
                                            stars : review.rating,
                                            comment : review.text
                                        };
                                        // Ajout de l'avis dans le newRestaurant
                                        newRestaurant.ratings.push(avis);
                                    }
                                }
                                // Update asynchrone, mise à jour de la moyenne dans l'objet
                                newRestaurant.avgRate = newRestaurant.avgRating();
                                // Update asynchrone, mise à jour de la sidebar
                                
                            }
                            else{
                                // Message d'erreur
                                console.error("Get reviews failed : " + status);
                            }
                            newRestaurant.addRestaurantToSidebar();
                        });
                      
                        
                    }
                }

                // On affiche ou masque les restaurants dans un rayon de 1 km par rapport à la userPosition
                checkRestaurants();
            }
            else{
                // Message d'erreur
                console.error("Request failed : " + status);
                // On affiche ou masque les restaurants dans un rayon de 1 km par rapport à la userPosition
                checkRestaurants();
            }
        });

});

        
  

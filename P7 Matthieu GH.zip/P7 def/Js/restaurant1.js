class Restaurant {
    // Constructor
    constructor(id, jsonFile){
        // Si un JSON est fournis
        if (jsonFile){
            // Initialisation des propriétés issues du JSON
            this.restaurantName = jsonFile.restaurantName;
            this.address = jsonFile.address;
            this.location = {
                lat : jsonFile.lat,
                lng : jsonFile.long
            }
            this.ratings = jsonFile.ratings;
            this.type = jsonFile.type;
        }
        else{
            // Tableau de ratings vide
            this.ratings = [];
            // Coordonnées : objet vide
            this.location = {};
        }
        // Identifiant unique permettant de manipuler le DOM sidebar à partir de l'objet
        this.id = "restaurant_" + id;
        // Indice du li dans la liste ul : déroulement du li via Materialize
        this.indice = id.toString();
        // On initialise la moyenne
        this.avgRate = this.avgRating();
    }

 // Méthode de calcul de la moyenne des notes
avgRating(){
        // On initialise les variables
        let numerateur = 0;
        let moyenne = 0;
        // Si pas d'avis
        if (this.ratings.length === 0){
            // On retourne une string
            return "Pas d'avis déposé sur cet établissement";
        }
        // S'il y a au moins 1 avis
        else {
            // On boucle sur les ratings
            for (let rating of this.ratings){
                numerateur += rating.stars;
            }
            // On retourne la moyenne avec 1 chiffre après la virgule
            moyenne = Math.round((numerateur/this.ratings.length)*10)/10;
            return moyenne;
        }
}

 // Méthode de mise à jour de descriptif
updateSideBar(){
        // MAJ  du rateYo dans le header du collapsible
            // On selectionne l emplacement
        let rateUpdate = $('#'+ this.id).find('div.rateElem');
            // On detruit l ancien rateYo
       console.log (this.ratings.length)
    if (this.ratings.length > 1){
        console.log ('avis')
       rateUpdate.rateYo("destroy");
            // On ajoute le nouveau rateYo
        rateUpdate.rateYo({
            rating : avgRating(this.ratings),
            starWidth: "20px",
            readOnly: true
         });
    }
    else {
        console.log ('pas d avis')
        rateUpdate.rateYo({
            rating : avgRating(this.ratings),
            starWidth: "20px",
            readOnly: true
         });
    }  
        // MAJ  de la moyenne dans le body du collapsible
        let moyUpdate = $('#'+ this.id).find('div.affichMoy').text("Moyenne des avis : " + avgRating(this.ratings));

        // Ajout de l avis dans la liste
        let ratingUpdate = $('#'+ this.id).find('div.listeAvis');
            // On vide la liste
            ratingUpdate.html('');
            // On ajoute les avis et le rateYo correspondant
            for (let ratings of this.ratings){ 
                // Création de l'élément p contenant l'avis
                let pRating = $('<p>').addClass("rating").text(": " + "\" " + ratings.comment + " \"");
                // Création d'un rateYo
                let rateAvis = $('<div/>');
                // Ajout du rating en JQ en read only
                $(rateAvis).rateYo({
                    rating : ratings.stars,             
                    starWidth: "15px",
                    readOnly: true
                })
            rateAvis.appendTo(ratingUpdate);
            pRating.appendTo(ratingUpdate);
            };
};


// Ajout du restaurant dans la barre de gauche
addRestaurantToSidebar(){
    // Création d'une li qui va dans l'ul
    var li = $('<li/>',{id : this.id}).appendTo($("ul"));
        // Ajout du header de notre collapsible avec icone , nom du restaurant et notation
        var liHeader = $('<div/>').addClass('collapsible-header waves-effect waves-teal').appendTo(li);
            // Insertion de l'image (icone) dans mon collaps-header
            let icon = $('<i>').addClass("material-icons").text("local_dining").appendTo(liHeader);
            // Insertion du nom du restaurant dans mon collapse-header
            $('<div/>').addClass('nomResto').text(this.restaurantName).appendTo(liHeader);
            // Insertion de la notation dans mon collaps-header
            let rateElem =  $('<div/>').addClass('rateElem waves-effect waves-teal').appendTo(liHeader);
            if (this.ratings.length > 0){
                // Si oui, on ajoute un rating rate-YO en JQ en read only
                rateElem.rateYo({
                    rating : avgRating(this.ratings),
                    starWidth: "20px",
                    readOnly: true
                });
            }
        
        // Ajout du body de notre collapsible
        var liBody = $('<div/>').addClass('collapsible-body').appendTo(li);
            // Création de l'icone adresse
            let iconAdresse = $('<i>').addClass("material-icons").text("location_on");
            // Ajout de l'adresse du restaurant
                // Creation de la div
            let adresse = $('<div/>').appendTo(liBody)
                // Ajout de l'icone adresse  
            iconAdresse.appendTo(adresse)   
            $('<div/>').addClass('adresse').text(this.address).appendTo(adresse);
            // Ajout de l'image google street
            let restaurantLocation = "location="+this.location.lat + "," + this.location.lng;
            let streetView = $('<div/>').addClass('streetview hide-on-small-only').appendTo(liBody);
            $('<img>').attr('src', 'https://maps.googleapis.com/maps/api/streetview?size=400x400&key=AIzaSyB48K7MnLGjHOLRg8YlZVgGg2kIj2zNrXU&'+restaurantLocation).appendTo(streetView);  
            // Ajout de la note moyenne
                // On calcule la moyenne des notes
            let avgRate= avgRating(this.ratings);
                // On affiche la moyenne des notes
            let affichMoy = $('<div/>').addClass('affichMoy').text("Moyenne des avis : " + avgRate).appendTo(liBody);
            // On crée un conteneur pour inserer les boutons
            let contBouton = $('<div/>').addClass('contBouton').appendTo(liBody);
            // ON CREE LES BOUTONS
                // On ajoute un bouton pour lire les avis
            let btnRating = $('<a>').text("Lire les avis").addClass("waves-effect waves-light btn");
                // On ajoute un bouton pour ajouter un avis
            let btnAddRating = $('<a>').text("Ajouter un avis").addClass("waves-effect waves-light btn modal-trigger").attr('href','#modal1');
            // On crée la div qui va regrouper tous les avis
            let allRating = $('<div/>').addClass('listeAvis');
            // On masque les ratings 
            allRating.hide();           
           
            // Au clic sur lire les avis on déroule ou ré-enroule la liste
            btnRating.on("click", function(e){
                    // On ne propage pas l'évènement pour ne pas trigger le reste du DOM
                    e.stopPropagation();
                    // SlideToggle JQ
                    allRating.slideToggle();
            });

            // Au clic ouverture d'une fenetre modal pour l'ajout d'un avis
            btnAddRating.on("click", () => {
            // On génère le rate-Yo
                    $(rateModal).rateYo({
                        starWidth: "25px",
                        halfStar: true
                    })
                    // Reset des valeurs de la modale
                    $("#modal1 h4").text("Donnez votre avis sur : " + this.restaurantName);
                    // Reset du rating
                    $(rateModal).rateYo("rating", 0);
                    // Reset de la textarea
                    avisModal.value = "";
                    // On remplit le champ caché contenant l'id du restaurant
                    console.log(this.id)
                    lastmodified.value = this.id;
            });

            $(liHeader).on("click", () => {
            // On centre la map sur le marqueur
            this.centerMap();
        });
            // On insere les bouton à la div ContBouton
            btnRating.appendTo(contBouton);
            btnAddRating.appendTo(contBouton);
            // On ajoute le conteneur des avis au liBody
            allRating.appendTo(liBody);
            // Création des avis
            for (let ratings of this.ratings){ 
            // Création de l'élément p contenant l'avis
            let pRating = $('<p>').addClass("rating").text(": " + "\" " + ratings.comment + " \"");
            // Création d'un rateYo
            let rateAvis = $('<div/>');
            // Ajout du rating en JQ en read only
            $(rateAvis).rateYo({
                rating : ratings.stars,               
                starWidth: "15px",
                readOnly: true
            });
            // Ajout du rating et du commentaire dans la rubrique avis
            rateAvis.appendTo(allRating);
            pRating.appendTo(allRating);
            }

}
// Ajout du marker au restaurant correspondant
addMarker(liIndex){
    // Création du marker
    this.marker = new google.maps.Marker({
        position: this.location,
        map: map
    });
    // A chaque click on ouvre le collapsible correspondant
    console.log(this.marker)
    this.marker.addListener("click", (e) => {
    $('.collapsible').collapsible('open', liIndex);
    this.centerMap();
    });
    
};

// Méthode pour centre la map sur le marqueur et animer le marqueur
centerMap(){
        // On centre la carte sur la position du restaurant
        map.panTo(this.location);
        // On anime le marqueur sélectionné
        this.marker.setAnimation(google.maps.Animation.BOUNCE);
        // On stop l'animation au bout de 1.1s - fonction fléchée pour que this puisse faire référence à l'instance de l'objet
        setTimeout(() => {this.marker.setAnimation(null);}, 1100);
    }
 // Méthode qui masque le descriptif
hideSideBar(){
    // Sélection du li du DOM via l'id
    let selecteur = "#" + this.id;
    // On utiliser JQ pour masquer l'élément
    $(selecteur).hide(200);
}
// Méthode qui affiche le descriptif
showSideBar(){
    // Sélection du li du DOM via l'id
    let selecteur = "#" + this.id;
    // On utiliser JQ pour afficher l'élément
    $(selecteur).show(200);    
}

// Méthode qui masque le marqueur
hideMarker(){
    this.marker.setVisible(false);
}

// Méthode qui affiche le marqueur
showMarker(){
    this.marker.setVisible(true);
}

// Méthode d'ajout d'avis
addRating(){
    // Récupération des données fournies par l'utilisateur dans la modale
    let avis = avisModal.value;
    let rating = $(rateModal).rateYo("rating");
    // On ajoute un avis dans l'objet
    this.ratings.push({
        stars : rating,
        comment : avis
    });
    console.log(this.ratings)
    // On recalcule la moyenne
    this.avgRate = this.avgRating();
    console.log (this.avgRate)
}

};
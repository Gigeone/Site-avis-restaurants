// Carte google maps
var map;

// Initialisation de la map
function initMap(){

	map = new google.maps.Map(document.getElementById("map"), {
		zoom: defaultZoom,
    center: userPosition
	});

	infoWindow = new google.maps.InfoWindow;
        // Try HTML5 geolocation.
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(function(position) {
          userPosition.lat = position.coords.latitude;
          userPosition.lng = position.coords.longitude;
            map.setCenter(userPosition);
            var marker = new google.maps.Marker({
    	         position: userPosition,
                map: map,
                title: 'Vous êtes ici',
                icon: 'http://maps.google.com/mapfiles/arrow.png'
            });

          }, function() {
            handleLocationError(true, infoWindow, map.getCenter());
          });
        } else {
          // Browser doesn't support Geolocation
          handleLocationError(false, infoWindow, map.getCenter());
        }
};
    
   

